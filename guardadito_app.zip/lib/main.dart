import 'package:flutter/material.dart';

void main() {
  runApp(const GuardaditoApp());
}

class GuardaditoApp extends StatelessWidget {
  const GuardaditoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text("Guardadito App")),
        body: const Center(child: Text("Hola 👋 Bienvenido a Guardadito App")),
      ),
    );
  }
}
